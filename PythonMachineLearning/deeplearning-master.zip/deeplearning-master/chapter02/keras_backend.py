from keras import backend
print(backend._BACKEND)