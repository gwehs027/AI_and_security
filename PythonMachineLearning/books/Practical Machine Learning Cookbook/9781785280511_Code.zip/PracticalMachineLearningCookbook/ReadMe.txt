Chapter 1 covers overviews of concepts and does not contain code.
The required support files can be found in the Data folder within the chapter folders.