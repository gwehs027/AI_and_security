# -*- coding: utf-8 -*-
"""
Created on Mon Jul 23 10:43:46 2018

@author: Administrator
"""

from visdom import Visdom
import numpy as np

vis = Visdom()

# mesh plot
x = [0, 0, 1, 1, 0, 0, 1, 1]
y = [0, 1, 1, 0, 0, 1, 1, 0]
z = [0, 0, 0, 0, 1, 1, 1, 1]
X = np.c_[x, y, z]
i = [7, 0, 0, 0, 4, 4, 6, 6, 4, 0, 3, 2]
j = [3, 4, 1, 2, 5, 6, 5, 2, 0, 1, 6, 3]
k = [0, 7, 2, 3, 6, 7, 1, 1, 5, 5, 7, 6]
Y = np.c_[i, j, k]

vis.mesh(X=X, Y=Y, opts=dict(opacity=0.5))
