# -*- coding: utf-8 -*-
"""
Created on Mon Jul 23 10:35:02 2018

@author: Administrator
"""

from visdom import Visdom
vis= Visdom()
vis.text('Hello, world !')
